
package com.mycompany.icetask31b;


public class Icetask {
     private String PatientGender;
    private String PatientName;
    private int PatientAge;
    private String  username;
    private String password;

    public Icetask(String PatientGender, String PatientName, int PatientAge) {
        this.PatientGender = PatientGender;
        this.PatientName = PatientName;
        this.PatientAge = PatientAge;
    }

  
    public String getPatientGender() {
        return PatientGender;
    }

    public void setPatientGender(String PatientGender) {
        this.PatientGender = PatientGender;
    }
     public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }
         public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }


    public String getPatientName() {
        return PatientName;
    }

    public void setPatientName(String PatientName) {
        this.PatientName = PatientName;
    }

    public int getPatientAge() {
        return PatientAge;
    }

    public void setPatientAge(int PatientAge) {
        this.PatientAge = PatientAge;
    }

    @Override
    public String toString() {
        return "Gender: " + PatientGender + ", Name: " + PatientName + ", Age: " + PatientAge;
    }
}

 

