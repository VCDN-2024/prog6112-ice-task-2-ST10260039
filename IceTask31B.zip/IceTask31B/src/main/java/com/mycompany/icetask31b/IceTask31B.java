

package com.mycompany.icetask31b;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class IceTask31B {
    private ArrayList<Icetask> Patients;
    private Scanner scanner; 


    public IceTask31B() {
        Patients = new ArrayList<>(); 
        scanner = new Scanner(System.in); 
    }
  
    public void savePatient() {
        scanner.nextLine(); 
        System.out.print("Enter Patient Gender: ");
        String PatientGender = scanner.nextLine();
        System.out.print("Enter Patient Name: ");
        String PatientName = scanner.nextLine();

        int PatientAge = 0;
        boolean validInput = false;

        while (!validInput) {
            System.out.print("Enter Patient's Age: ");
            try {
                PatientAge = scanner.nextInt();
                if (PatientAge < 0 ) {
                    System.out.println("Patient ");
                } else {
                    validInput = true;
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a numeric value for Patients Age.");
                scanner.next(); 
            }
        }

        Icetask newIcetask = new Icetask(PatientGender, PatientName, PatientAge);
        Patients.add(newIcetask);
        
        System.out.println("Product saved successfully.");
    }
    
      public void savePatient(String PatientGender, String PatientName, int PatientAge) {
        Icetask newIcetask = new Icetask(PatientGender, PatientName, PatientAge);
        Patients.add(newIcetask);
        System.out.println("Product saved successfully.");
    }
//scanner.hasNextInt
    
   
    public Icetask searchPatient(String productId) {
        for (Icetask product : Patients) {
            if (product.getPatientName().equalsIgnoreCase(productId)) {
                return product;  
            }
        }
        return null; 
    }

 
    public void deletePatient() {
        scanner.nextLine(); 
        System.out.print("Enter Product ID to delete: ");
        String PatientName = scanner.nextLine();
        boolean found = false;

        for (Icetask product : Patients) {
            if (product.getPatientName().equalsIgnoreCase(PatientName)) {
                System.out.print("Are you sure you want to delete this patient? (y/n): ");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("y")) {
                    Patients.remove(product);
                    System.out.println("Product deleted successfully.");
                } else {
                    System.out.println("Deletion canceled.");
                }
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Patient not found.");
        }
    }


    public void printPatientsReport() {
        if (Patients.isEmpty()) {
            System.out.println("No patients available.");
        } else {
            System.out.println("\nPatient List:");
            for (Icetask product : Patients) {
                System.out.println(product);
            }
        }
    }

    
    public void exitApplication() {
        System.out.println("Exiting application. Goodbye!");
    }


    public ArrayList<Icetask> getProducts() {
        return Patients;
    }


    public void launchMenu() {
       System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Save a new Patient");
            System.out.println("2. Search for a Patient");
            System.out.println("3. Delete a Patient file");
            System.out.println("4. Print Patient list");
            System.out.println("5. Exit application");
            System.out.print("Enter your choice: ");
            
            int choice;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Exiting application.");
                break;
            }

            switch (choice) {
                case 1:
                    savePatient(); 
                    break;
                case 2:
                    scanner.nextLine(); 
                    System.out.print("Enter Patient name to search: ");
                    String searchId = scanner.nextLine();
                    Icetask foundProduct = searchPatient(searchId);
                    if (foundProduct != null) {
                        System.out.println("Patient found: " + foundProduct);
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;
                case 3:
                    deletePatient(); 
                    break;
                case 4:
                    printPatientsReport();
                    break;
                case 5:
                    exitApplication(); 
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }


    public static void main(String[] args) {
        IceTask31B manager = new IceTask31B();
        System.out.print("Press 1 to launch menu, any other key to exit: ");
        Scanner input = new Scanner(System.in);
        String choice = input.nextLine();

        if (choice.equals("1")) {
            manager.launchMenu();
        } else {
            System.out.println("Exiting application. Goodbye!");
        }
    }
}

